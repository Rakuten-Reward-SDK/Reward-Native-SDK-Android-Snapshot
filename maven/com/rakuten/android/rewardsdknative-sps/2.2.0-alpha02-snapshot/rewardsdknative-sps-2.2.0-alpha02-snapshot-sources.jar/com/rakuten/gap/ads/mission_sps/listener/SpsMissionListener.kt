package com.rakuten.gap.ads.mission_sps.listener

import com.rakuten.gap.ads.mission_sps.activity.mode.MissionTheme

/**
 *
 * @author zack.keng
 * Created on 2024/04/08
 * Copyright © 2024 Rakuten Asia. All rights reserved.
 */
interface SpsMissionListener {
    fun onThemeChanged(theme: MissionTheme)
}