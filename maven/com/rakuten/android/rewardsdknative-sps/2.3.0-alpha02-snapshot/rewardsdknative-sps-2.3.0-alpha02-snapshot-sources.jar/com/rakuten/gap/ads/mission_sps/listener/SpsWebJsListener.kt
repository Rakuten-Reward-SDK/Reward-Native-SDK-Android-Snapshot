package com.rakuten.gap.ads.mission_sps.listener

import android.app.Activity
import android.webkit.JavascriptInterface
import android.webkit.WebView
import com.rakuten.gap.ads.common.activity.startActivityForResultCompat
import com.rakuten.gap.ads.common.logger.RewardDebugLog
import com.rakuten.gap.ads.mission_core.helpers.RemoteResources
import com.rakuten.gap.ads.mission_core.helpers.getString
import com.rakuten.gap.ads.mission_sps.activity.RakutenRewardSpsPortalActivity
import com.rakuten.gap.ads.mission_sps.ads.RakutenMissionSpsAds
import com.rakuten.gap.ads.mission_sps.ads.RakutenRewardAdResult
import com.rakuten.gap.ads.mission_sps.api.RakutenMissionSps
import com.rakuten.gap.ads.mission_sps.internal.InternalMissionSps
import com.rakuten.gap.ads.mission_sps.internal.createAdLoadingDialog
import com.rakuten.gap.ads.mission_sps.internal.SpsRemoteText
import com.rakuten.gap.ads.mission_sps.internal.toWebViewLandingPageModel
import jp.co.rakuten.sps.web.ScreenSdk
import jp.co.rakuten.sps.web.model.ads.LandingPageAdModel
import jp.co.rakuten.sps.web.webview.ScreenWebViewActivity
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import java.lang.ref.WeakReference

/**
 * @suppress
 *
 * This is a JS interface for the SPS mobile web page to communicate with the app.
 *
 * @author zack.keng
 * Created on 2024/01/22
 * Copyright © 2024 Rakuten Asia. All rights reserved.
 */
class SpsWebJsListener(webView: WebView, private val remoteResources: RemoteResources) {
    companion object {
        private const val TAG = "SpsWebJsListener"
    }

    private val webViewWeakRef = WeakReference(webView)

    private val json: Json by lazy {
        Json {
            ignoreUnknownKeys = true
        }
    }

    @JavascriptInterface
    fun closeWebView() {
        RewardDebugLog.d(TAG, "Close webview")
        webViewWeakRef.get()?.let {
            (it.context as Activity).finish()
        }
    }

    @JavascriptInterface
    fun reload() {
        RewardDebugLog.d(TAG, "Reload webview")
        webViewWeakRef.get()?.post {
            webViewWeakRef.get()?.reload()
        }
    }

    @JavascriptInterface
    fun getErrorMessage(): String {
        RewardDebugLog.d(TAG, "Get error message")
        return remoteResources.getString(SpsRemoteText.SPS_WEB_ERROR_MSG).replace("\\n", "<br>")
    }

    @JavascriptInterface
    fun getRetryButtonText(): String {
        RewardDebugLog.d(TAG, "Get retry button text")
        return remoteResources.getString(SpsRemoteText.SPS_WEB_ERROR_RETRY)
    }

    @JavascriptInterface
    fun getSpsAccessToken(callback: String) {
        RewardDebugLog.d(TAG, "Get Token [$callback]")
        CoroutineScope(Dispatchers.IO).launch(
            context = CoroutineExceptionHandler { _, throwable ->
                RewardDebugLog.e(TAG, "Error occurred getting SPS token - $throwable", throwable)
            }
        ) {
            val token = try {
                ScreenSdk.INSTANCE.getSpsToken().accessToken
            } catch (_: Throwable) {
                ""
            }
            withContext(Dispatchers.Main) {
                webViewWeakRef.get()?.loadUrl(String.format(callback, token))
            }
        }
    }

    @JavascriptInterface
    fun openLandingPage(landingPageAdData: String) {
        RewardDebugLog.d(TAG, "Open landing page [$landingPageAdData]")
        try {
            val landingPageAdModel: LandingPageAdModel = json.decodeFromString(landingPageAdData)
            webViewWeakRef.get()?.let { webView ->
                val context = webView.context
                val adRequestData = InternalMissionSps.getAdRequestData()
                if (context is RakutenRewardSpsPortalActivity) {
                    context.setAdClicked(landingPageAdModel.id)
                }
                val intent = ScreenWebViewActivity.getIntent(
                    context = context,
                    ad = landingPageAdModel.toWebViewLandingPageModel(),
                    adRequestData = adRequestData
                )
                (context as Activity).startActivity(intent)
            }
        } catch (e: Exception) {
            RewardDebugLog.w("SpsWebJsListener", "Error occurred opening landing page", e)
        }
    }

    @JavascriptInterface
    fun openLandingPage(landingPageAdData: String, callback: String) {
        RewardDebugLog.d(TAG, "Open landing page [$landingPageAdData], callback: $callback")
        try {
            val landingPageAdModel: LandingPageAdModel = json.decodeFromString(landingPageAdData)
            webViewWeakRef.get()?.let { webView ->
                val context = webView.context
                val adRequestData = InternalMissionSps.getAdRequestData()
                if (context is RakutenRewardSpsPortalActivity) {
                    context.setAdClicked(landingPageAdModel.id)
                }
                val intent = ScreenWebViewActivity.getIntent(
                    context = context,
                    ad = landingPageAdModel.toWebViewLandingPageModel(),
                    adRequestData = adRequestData
                )
                (context as Activity).startActivityForResultCompat(
                    intent, 822, "sps-landing-page"
                ) {
                    if (it.resultCode == ScreenWebViewActivity.RESULT_POINT_SUCCESS) {
                        RewardDebugLog.d(TAG, "Triggered callback: $callback")
                        webView.post {
                            webView.loadUrl(callback)
                        }
                        showInterstitialAd(context)
                    }
                }
            }
        } catch (e: Exception) {
            RewardDebugLog.w("SpsWebJsListener", "Error occurred opening landing page", e)
        }
    }

    private fun showInterstitialAd(activity: Activity) {
        val adConfig = ScreenSdk.INSTANCE.getInterstitialAdConfig(RakutenMissionSps.platform)
        if (!RakutenMissionSpsAds.isInterstitialAdProviderRegistered || adConfig.adUnitId.isNullOrBlank()) return
        if (activity.isFinishing || activity.isDestroyed) return
        val loadingDialog = createAdLoadingDialog(activity)
        loadingDialog.show()
        RakutenMissionSpsAds.showInterstitialAd(activity, adConfig) { result ->
            if (!activity.isFinishing && !activity.isDestroyed) {
                loadingDialog.dismiss()
            }
            if (result is RakutenRewardAdResult.AdShown) {
                RakutenMissionSpsAds.preLoadInterstitialAd(activity, adConfig)
            }
        }
    }
}