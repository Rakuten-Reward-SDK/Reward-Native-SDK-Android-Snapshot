package com.rakuten.gap.ads.mission_sps.api

import com.rakuten.gap.ads.common.logger.RewardDebugLog
import com.rakuten.gap.ads.mission_sps.internal.InternalMissionSps
import com.rakuten.gap.ads.mission_sps.internal.SpsGeoLocation
import com.rakuten.gap.ads.mission_sps.listener.SpsMissionListener
import com.rakuten.gap.ads.mission_sps.ads.RakutenMissionSpsAds
import jp.co.rakuten.sps.web.ScreenSdk
import jp.co.rakuten.sps.web.model.auth.SpsCompatToken

/**
 * This class provides the main API for SPS feature.
 *
 * In order to show SPS Ads, you need to initialize the SDK with the platform name and a token provider.
 * ```kotlin
 *  RakutenMissionSps.init("platform-name", object : SpsTokenProvider {
 *    override suspend fun getExchangeToken(): String? {
 *      // Fetch the CAT exchange token from your server
 *    }
 * ```
 *
 * Created on 2024/01/16
 * Copyright © 2024 Rakuten Asia. All rights reserved.
 */
object RakutenMissionSps {

    /**
     * Initialize the SPS SDK with the platform name and a token provider.
     *
     * @param platform The platform name
     * @param provideToken A lambda that should return a nullable SpsCompatToken that is the auth token to be provided to SPS Web SDK.
     *
     */
    fun init(platform: String, provideToken: suspend () -> SpsCompatToken?) {
        RewardDebugLog.d("RakutenMissionSps", "init SPS SDK")
        setPlatform(platform)
        setSpsTokenProvider(provideToken)
        InternalMissionSps.registerSdkCallbacks()
        RakutenMissionSpsAds.preLoadInterstitialAd(ScreenSdk.appContext, ScreenSdk.INSTANCE.getInterstitialAdConfig(platform))
    }

    internal var platform: String = ""
        private set

    internal var geoLocation: SpsGeoLocation? = null
        private set

    internal var spsMissionListener: SpsMissionListener? = null
        private set

    private fun setSpsTokenProvider(provideToken: suspend () -> SpsCompatToken?) {
        RewardDebugLog.d("RakutenMissionSps", "Set Token Provider")
        ScreenSdk.INSTANCE.setSdkTokenProvider(provideToken)
    }

    /**
     * Update the platform name
     */
    fun setPlatform(platform: String) {
        this.platform = platform
    }

    /**
     * Set the SPS mission listener to receive the theme change event.
     */
    fun setSpsMissionListener(listener: SpsMissionListener) {
        spsMissionListener = listener
    }

    /**
     * In order to provide a better Ad experience to end users, you can provide users' current
     * latitude and longitude.
     *
     * @param lat latitude
     * @param long longitude
     */
    fun setLocation(lat: Float, long: Float) {
        geoLocation = SpsGeoLocation.newInstance(lat, long)
    }

    /**
     * Clear the SPS token cache.
     */
    fun clearSpsToken() {
        InternalMissionSps.clearSpsUserCache()
        ScreenSdk.INSTANCE.clearSpsToken()
    }

}