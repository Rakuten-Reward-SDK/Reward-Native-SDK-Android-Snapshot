package com.rakuten.gap.ads.mission_sps.ads

import android.app.Activity
import android.content.Context
import jp.co.rakuten.sps.web.model.InterstitialAdConfig

/**
 * Entry point for SPS interstitial ad functionality.
 *
 * This object acts as a registry that decouples the [InterstitialAdProvider] implementation
 * from the SPS SDK. Consumers who want Google Interstitial Ads support should add the
 * `mission-ads` module as a dependency — the provider is registered automatically at startup
 * via a [android.content.ContentProvider] and requires no manual initialisation.
 *
 * If no provider is registered, [preLoadInterstitialAd] is a no-op and
 * [showInterstitialAd] always returns [RakutenRewardAdResult.NoAdShown].
 *
 * Created on 2026/05/13
 * Copyright © 2026 Rakuten Asia. All rights reserved.
 */
object RakutenMissionSpsAds {

    private var provider: InterstitialAdProvider? = null

    /**
     * Returns `true` if an [InterstitialAdProvider] has been registered.
     *
     * Use this to conditionally show a loading indicator before calling [showInterstitialAd].
     */
    val isInterstitialAdProviderRegistered: Boolean
        get() = provider != null

    /**
     * Registers the [InterstitialAdProvider] implementation.
     *
     * This is called automatically when the `mission-ads` module is present.
     * There is no need to call this manually unless providing a custom implementation.
     *
     * @param provider The [InterstitialAdProvider] implementation to register.
     */
    fun registerInterstitialAdProvider(provider: InterstitialAdProvider) {
        this.provider = provider
    }

    /**
     * Pre-loads an interstitial ad in the background so it is ready to display without delay.
     *
     * This is a no-op if:
     * - No [InterstitialAdProvider] is registered.
     * - A valid cached ad already exists within the [InterstitialAdConfig.adCacheTimeMillis] window.
     * - [InterstitialAdConfig.adUnitId] is null or empty.
     *
     * @param context Application or Activity context used to load the ad.
     * @param adConfig Configuration retrieved from `ScreenSdk.getInterstitialAdConfig(platform)`.
     */
    fun preLoadInterstitialAd(context: Context, adConfig: InterstitialAdConfig) {
        provider?.preLoad(context, adConfig)
    }

    /**
     * Shows a pre-loaded interstitial ad, loading one on-demand if the cache is empty or stale.
     *
     * The result is delivered via [adResult] on the main thread:
     * - [RakutenRewardAdResult.AdShown] — the ad was displayed successfully.
     * - [RakutenRewardAdResult.NoAdShown] — no ad was shown (no provider registered, no ad unit ID,
     *   load failure, or load timeout exceeded).
     *
     * @param activity The foreground [Activity] used to display the ad.
     * @param adConfig Configuration retrieved from `ScreenSdk.getInterstitialAdConfig(platform)`.
     *   If [InterstitialAdConfig.adUnitId] is empty, [RakutenRewardAdResult.NoAdShown] is returned immediately.
     * @param adResult Callback invoked once with the ad display result.
     */
    fun showInterstitialAd(
        activity: Activity,
        adConfig: InterstitialAdConfig,
        adResult: (RakutenRewardAdResult) -> Unit
    ) {
        val p = provider
        if (p == null) {
            adResult(RakutenRewardAdResult.NoAdShown)
            return
        }
        p.showAd(activity, adConfig, adResult)
    }
}
