package com.rakuten.gap.ads.mission_ui.api.activity

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.lifecycle.lifecycleScope
import com.rakuten.gap.ads.mission_core.RakutenRewardConfig
import com.rakuten.gap.ads.mission_core.data.EventItem
import com.rakuten.gap.ads.mission_core.helpers.getRemoteResources
import com.rakuten.gap.ads.mission_core.helpers.getString
import com.rakuten.gap.ads.mission_core.internal.EventNames
import com.rakuten.gap.ads.mission_core.internal.SdkModuleApi
import com.rakuten.gap.ads.mission_core.modules.singleton.RewardSDKAdModule
import com.rakuten.gap.ads.mission_ui.R
import com.rakuten.gap.ads.mission_ui.ui.adapter.item.SettingItem
import com.rakuten.gap.ads.mission_ui.ui.utils.UIRemoteText
import kotlinx.coroutines.launch

/**
 * Rakuten Reward Settings screen
 */
class RakutenRewardSettingActivity : AppCompatActivity() {
    companion object {
        private const val BUNDLE_TITLE = "toolbar-title"
        private const val BUNDLE_UNCLAIM_NOTIFICATION = "unclaim-notification"

        fun getIntent(context: Context, titleKey: String, unclaimNotification: String): Intent {
            return Intent(context, RakutenRewardSettingActivity::class.java).apply {
                putExtra(BUNDLE_TITLE, titleKey)
                putExtra(BUNDLE_UNCLAIM_NOTIFICATION, unclaimNotification)
            }
        }
    }

    @SuppressLint("SourceLockedOrientationActivity")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Opt into edge-to-edge on all API levels; Android 15+ enforces this automatically.
        // White toolbar background requires dark status bar icons (light appearance).
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowCompat.getInsetsController(window, window.decorView)
            .isAppearanceLightStatusBars = true

        if (RewardSDKAdModule.isSpsEnabled()) {
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
        }

        val remoteResources = getRemoteResources()
        val titleKey = intent.getStringExtra(BUNDLE_TITLE) ?: UIRemoteText.PORTAL_OTHER_NOTIFICATION
        val title = remoteResources.getString(titleKey)

        val unclaimNotificationKey = intent.getStringExtra(BUNDLE_UNCLAIM_NOTIFICATION)
            ?: UIRemoteText.PORTAL_NOTIFICATION_UNCLAIM
        val items = listOf(
            SettingItem(
                SettingItem.PointNotification(unclaimNotificationKey),
                RakutenRewardConfig.isUiEnabled()
            )
        )
        val resolvedTitles = items.associate { it.type.titleKey to remoteResources.getString(it.type.titleKey) }

        setContent {
            SettingScreen(
                title = title,
                items = items,
                resolvedTitles = resolvedTitles,
                onBack = { finish() },
                onSwitchChanged = { type, enabled -> handleSwitch(type, enabled) }
            )
        }
    }

    private fun handleSwitch(settingType: SettingItem.SettingType, status: Boolean) {
        when (settingType) {
            is SettingItem.PointNotification -> {
                cacheEvent(if (status) "enable" else "disable")
                RakutenRewardConfig.setUiEnabled(status)
            }
        }
    }

    private fun cacheEvent(status: String) {
        val eventItem = EventItem.createItem(EventNames.TOGGLE_NOTIFICATION).apply {
            addExtra(EventNames.EXTRA_STATUS, status)
        }
        lifecycleScope.launch {
            SdkModuleApi.sendEventInCoroutine(eventItem)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SettingScreen(
    title: String,
    items: List<SettingItem>,
    resolvedTitles: Map<String, String>,
    onBack: () -> Unit,
    onSwitchChanged: (SettingItem.SettingType, Boolean) -> Unit
) {
    Scaffold(
        topBar = { SettingToolbar(title = title, onBack = onBack) },
        containerColor = Color.White
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = innerPadding
        ) {
            items(items) { item ->
                SettingRow(
                    title = resolvedTitles[item.type.titleKey].orEmpty(),
                    initialState = item.initialState,
                    onCheckedChange = { enabled -> onSwitchChanged(item.type, enabled) }
                )
                Divider(color = Color(0xFFCCCCCC))
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SettingToolbar(title: String, onBack: () -> Unit) {
    Column {
        CenterAlignedTopAppBar(
            title = {
                Text(
                    text = title,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF333333)
                )
            },
            navigationIcon = {
                IconButton(onClick = onBack) {
                    Icon(
                        painter = painterResource(R.drawable.rakutenreward_ic_arrow_left),
                        contentDescription = stringResource(R.string.rakutenreward_close_portal),
                        tint = Color.Unspecified
                    )
                }
            },
            colors = TopAppBarDefaults.centerAlignedTopAppBarColors(containerColor = Color.White),
            // Let the TopAppBar consume the status bar inset so it extends behind it.
            windowInsets = WindowInsets.statusBars
        )
        Divider(color = Color(0xFFCCCCCC))
    }
}

@Composable
private fun SettingRow(
    title: String,
    initialState: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    var checked by remember { mutableStateOf(initialState) }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(60.dp)
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = title,
            modifier = Modifier.weight(1f),
            fontSize = 18.sp,
            color = Color(0xFF717171),
            maxLines = 2
        )
        Switch(
            checked = checked,
            onCheckedChange = { enabled ->
                checked = enabled
                onCheckedChange(enabled)
            }
        )
    }
}