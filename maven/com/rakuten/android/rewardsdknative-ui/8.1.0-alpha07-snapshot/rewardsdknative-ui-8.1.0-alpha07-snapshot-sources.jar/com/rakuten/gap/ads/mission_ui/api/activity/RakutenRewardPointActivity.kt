package com.rakuten.gap.ads.mission_ui.api.activity

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.rakuten.gap.ads.common.logger.RewardDebugLog
import com.rakuten.gap.ads.mission_core.RakutenReward
import com.rakuten.gap.ads.mission_core.RakutenRewardLifecycle
import com.rakuten.gap.ads.mission_core.api.status.RakutenRewardClaimStatus
import com.rakuten.gap.ads.mission_core.data.MissionAchievementData
import com.rakuten.gap.ads.mission_core.data.RakutenRewardPoint
import com.rakuten.gap.ads.mission_core.data.RakutenRewardUser
import com.rakuten.gap.ads.mission_core.helpers.RemoteResources
import com.rakuten.gap.ads.mission_core.helpers.getRemoteResources
import com.rakuten.gap.ads.mission_core.helpers.getString
import com.rakuten.gap.ads.mission_core.listeners.RakutenRewardListener
import com.rakuten.gap.ads.mission_core.modules.singleton.RewardSDKActivityModule
import com.rakuten.gap.ads.mission_core.modules.singleton.RewardSDKAdModule
import com.rakuten.gap.ads.mission_core.status.RakutenRewardSDKStatus
import com.rakuten.gap.ads.mission_core.ui.dialog.RakutenRewardSimpleConfirmationDialogListener
import com.rakuten.gap.ads.mission_ui.databinding.RakutenrewardUiPointhistoryActivityBinding
import com.rakuten.gap.ads.mission_ui.ui.utils.UIRemoteText
import com.rakuten.gap.ads.mission_ui.ui.utils.setPointLabel
import com.rakuten.gap.ads.mission_ui.ui.utils.toPointFormat
import com.rakuten.gap.ads.mission_ui.ui.view.PointHistoryItemView
import com.rakuten.gap.ads.mission_ui.viewmodel.PointViewModel

/**
 * Rakuten Reward Point History screen
 */
class RakutenRewardPointActivity : AppCompatActivity(),
    RakutenRewardSimpleConfirmationDialogListener, RakutenRewardListener {
    companion object {
        private const val TOKENEXPIRECODE = 100
        private const val BUNDLE_TITLE = "toolbar-title"
        private const val BUNDLE_TOP_DESC = "top-desc"
        private const val BUNDLE_POINT_TITLE = "point-title"
        private const val BUNDLE_EMPTY_MESSAGE = "empty-message"
        private const val BUNDLE_ERROR_MESSAGE = "error-message"
        private const val BUNDLE_DESC = "desc"

        fun getIntent(context: Context, titleKey: String): Intent {
            return Intent(context, RakutenRewardPointActivity::class.java).apply {
                putExtra(BUNDLE_TITLE, titleKey)
            }
        }

        fun getIntent(
            context: Context, titleKey: String, topDesc: String,
            pointTitle: String, emptyMessage: String, errorMessage: String, desc: String
        ): Intent {
            return Intent(context, RakutenRewardPointActivity::class.java).apply {
                putExtra(BUNDLE_TITLE, titleKey)
                putExtra(BUNDLE_TOP_DESC, topDesc)
                putExtra(BUNDLE_POINT_TITLE, pointTitle)
                putExtra(BUNDLE_EMPTY_MESSAGE, emptyMessage)
                putExtra(BUNDLE_ERROR_MESSAGE, errorMessage)
                putExtra(BUNDLE_DESC, desc)
            }
        }
    }

    private lateinit var binding: RakutenrewardUiPointhistoryActivityBinding

    private val viewModel: PointViewModel by viewModels()

    private val remoteResources: RemoteResources by lazy {
        getRemoteResources()
    }

    @SuppressLint("SourceLockedOrientationActivity")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        RewardDebugLog.d("PointHistory", "onCreate")
        binding = RakutenrewardUiPointhistoryActivityBinding.inflate(layoutInflater)
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, 0, systemBars.right, systemBars.bottom)
            insets
        }
        if (RewardSDKAdModule.isSpsEnabled()) {
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
        }

        setUpView()
        binding.viewModel = viewModel
        viewModel.point.set(RakutenReward.user.point.toPointFormat())

        RakutenReward.addRakutenRewardListener(this)
        RakutenRewardLifecycle.onCreate(this)
        viewModel.pointHistory.observe(this) {
            updatePointHistory(it)
        }
        binding.lifecycleOwner = this
    }

    override fun onStart() {
        super.onStart()
        RewardDebugLog.d("PointHistory", "onStart")
        RakutenRewardLifecycle.onStart(this)
        binding.rakutenrewardToolbar.rakutenrewardPortalclose.setOnClickListener { finish() }
    }

    override fun onResume() {
        super.onResume()
        RakutenRewardLifecycle.onResume(this)
    }

    override fun onDestroy() {
        super.onDestroy()
        RakutenReward.removeRakutenRewardListener(this)
    }

    override fun onUnclaimedAchievement(achievement: MissionAchievementData) = Unit

    override fun onUserUpdated(user: RakutenRewardUser) = Unit

    /* RakutenRewardListener */
    override fun onSDKStatusChanged(status: RakutenRewardSDKStatus) {
        RewardDebugLog.d("PointHistory", "onSDKStatusChanged: $status")
        when (status) {
            RakutenRewardSDKStatus.ONLINE -> {
                viewModel.pointHistoryUpdate()
            }

            RakutenRewardSDKStatus.OFFLINE -> {
                viewModel.pointError()
            }

            RakutenRewardSDKStatus.TOKENEXPIRED -> {
                RewardSDKActivityModule.openTokenExpireDialog(this)
            }

            else -> Unit
        }
    }

    override fun onSDKClaimClosed(
        missionAchievementData: MissionAchievementData,
        status: RakutenRewardClaimStatus
    ) = Unit

    override fun onSDKConsentClosed() = Unit

    override fun onSDKConsentPresented() = Unit

    override fun onSDKClaimPresented(missionAchievementData: MissionAchievementData) = Unit

    /* RakutenRewardSimpleConfirmationDialogListener */
    override fun closeRakutenRewardConfirmationDialog() {
        setResult(TOKENEXPIRECODE)
        finish()
    }

    private fun updatePointHistory(data: List<RakutenRewardPoint>) {
        if (data.isNotEmpty()) {
            with(binding.rakutenrewardPointhistoryHistoryContainer) {
                visibility = View.VISIBLE
                removeAllViews()
                data.forEach {
                    val view = PointHistoryItemView(context)
                    view.bindData(remoteResources, it)
                    addView(view)
                }
            }
        } else {
            binding.rakutenrewardPointhistoryHistoryContainer.visibility = View.GONE
        }

    }

    private fun setUpView() {
        val title = intent.getStringExtra(BUNDLE_TITLE) ?: UIRemoteText.PORTAL_OTHER_POINT_HISTORY
        val topDesc = intent.getStringExtra(BUNDLE_TOP_DESC) ?: UIRemoteText.PORTAL_HISTORY_TOP_DESC
        val errorMessageKey = intent.getStringExtra(BUNDLE_ERROR_MESSAGE)
            ?: UIRemoteText.PORTAL_HISTORY_ERROR
        val noHistoryKey = intent.getStringExtra(BUNDLE_EMPTY_MESSAGE)
            ?: UIRemoteText.PORTAL_HISTORY_EMPTY
        val desc = intent.getStringExtra(BUNDLE_DESC)
            ?: UIRemoteText.PORTAL_HISTORY_LABEL
        val pointTitle = intent.getStringExtra(BUNDLE_POINT_TITLE)
            ?: UIRemoteText.PORTAL_HISTORY_CURRENT_MONTH
        with(binding) {
            errorMessage = remoteResources.getString(errorMessageKey)
            infoMessage = remoteResources.getString(noHistoryKey)

            headerTitle = remoteResources.getString(title)

            rakutenrewardPointhistoryTopDesc.text = remoteResources.getString(topDesc)
            rakutenrewardPointhistoryTitle.text = remoteResources.getString(pointTitle)
            rakutenrewardPointhistoryPointtitle.setPointLabel(
                remoteResources,
                RakutenReward.user.point
            )
            rakutenrewardPointhistoryDesc.text = remoteResources.getString(desc)
        }
    }
}