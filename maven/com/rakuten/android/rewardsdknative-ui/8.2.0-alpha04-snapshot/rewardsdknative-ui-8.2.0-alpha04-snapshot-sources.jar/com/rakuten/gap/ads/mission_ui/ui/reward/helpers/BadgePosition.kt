package com.rakuten.gap.ads.mission_ui.ui.reward.helpers

/**
 * Enumeration class for Badge Position
 */
enum class BadgePosition {
    TOP_LEFT, TOP_RIGHT, BOTTOM_LEFT, BOTTOM_RIGHT, CENTER
}