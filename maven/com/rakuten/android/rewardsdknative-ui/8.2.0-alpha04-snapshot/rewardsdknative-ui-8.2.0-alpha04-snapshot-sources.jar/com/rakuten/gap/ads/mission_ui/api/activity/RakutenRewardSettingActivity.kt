package com.rakuten.gap.ads.mission_ui.api.activity

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import com.rakuten.gap.ads.mission_core.RakutenRewardConfig
import com.rakuten.gap.ads.mission_core.data.EventItem
import com.rakuten.gap.ads.mission_core.helpers.getRemoteResources
import com.rakuten.gap.ads.mission_core.helpers.getString
import com.rakuten.gap.ads.mission_core.internal.EventNames
import com.rakuten.gap.ads.mission_core.internal.SdkModuleApi
import com.rakuten.gap.ads.mission_core.modules.singleton.RewardSDKAdModule
import com.rakuten.gap.ads.mission_ui.R
import com.rakuten.gap.ads.mission_ui.databinding.RakutenrewardUiSettingActivityBinding
import com.rakuten.gap.ads.mission_ui.ui.adapter.RakutenRewardSettingItemAdapter
import com.rakuten.gap.ads.mission_ui.ui.adapter.item.SettingItem
import com.rakuten.gap.ads.mission_ui.ui.utils.UIRemoteText
import kotlinx.coroutines.launch

/**
 * Rakuten Reward Settings screen
 */
class RakutenRewardSettingActivity : AppCompatActivity() {
    companion object {
        private const val BUNDLE_TITLE = "toolbar-title"
        private const val BUNDLE_UNCLAIM_NOTIFICATION = "unclaim-notification"

        fun getIntent(context: Context, titleKey: String, unclaimNotification: String): Intent {
            return Intent(context, RakutenRewardSettingActivity::class.java).apply {
                putExtra(BUNDLE_TITLE, titleKey)
                putExtra(BUNDLE_UNCLAIM_NOTIFICATION, unclaimNotification)
            }
        }
    }

    private lateinit var binding: RakutenrewardUiSettingActivityBinding

    private lateinit var adapter: RakutenRewardSettingItemAdapter

    @SuppressLint("SourceLockedOrientationActivity")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = RakutenrewardUiSettingActivityBinding.inflate(layoutInflater)
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, 0, systemBars.right, systemBars.bottom)
            insets
        }
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.VANILLA_ICE_CREAM) {
            WindowCompat.getInsetsController(window, window.decorView)
                .isAppearanceLightStatusBars = true
        }
        if (RewardSDKAdModule.isSpsEnabled()) {
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
        }

        val titleKey = intent.getStringExtra(BUNDLE_TITLE) ?: UIRemoteText.PORTAL_OTHER_NOTIFICATION
        binding.headerTitle = getRemoteResources().getString(titleKey)

        val unclaimNotification = intent.getStringExtra(BUNDLE_UNCLAIM_NOTIFICATION)
            ?: UIRemoteText.PORTAL_NOTIFICATION_UNCLAIM
        val list = mutableListOf<SettingItem>()
        list.add(
            SettingItem(
                SettingItem.PointNotification(unclaimNotification),
                RakutenRewardConfig.isUiEnabled()
            )
        )
        adapter = RakutenRewardSettingItemAdapter(
            this, R.layout.rakutenreward_ui_setting_row, list, this::handleSwitch
        )
        adapter.setRemoteResources(getRemoteResources())
        binding.rakutenrewardSettingList.adapter = adapter
        binding.rakutenrewardToolbar.rakutenrewardPortalclose.setOnClickListener { finish() }
        binding.lifecycleOwner = this
    }

    private fun handleSwitch(settingType: SettingItem.SettingType, status: Boolean) {
        when (settingType) {
            is SettingItem.PointNotification -> {
                cacheEvent(if (status) "enable" else "disable")
                RakutenRewardConfig.setUiEnabled(status)
            }
        }
    }

    private fun cacheEvent(status: String) {
        val eventItem = EventItem.createItem(EventNames.TOGGLE_NOTIFICATION).apply {
            addExtra(EventNames.EXTRA_STATUS, status)
        }
        lifecycleScope.launch {
            SdkModuleApi.sendEventInCoroutine(eventItem)
        }
    }
}