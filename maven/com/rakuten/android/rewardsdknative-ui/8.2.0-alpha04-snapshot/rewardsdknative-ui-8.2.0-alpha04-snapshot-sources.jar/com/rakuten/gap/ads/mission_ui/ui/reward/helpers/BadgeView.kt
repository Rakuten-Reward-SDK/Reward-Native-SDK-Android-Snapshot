package com.rakuten.gap.ads.mission_ui.ui.reward.helpers

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ShapeDrawable
import android.graphics.drawable.shapes.RoundRectShape
import android.util.AttributeSet
import android.view.Gravity
import android.view.View
import android.view.animation.Animation
import android.widget.FrameLayout
import android.widget.TextView
import com.rakuten.gap.ads.mission_core.helpers.UIHelper.dipToPixel
import com.rakuten.gap.ads.mission_core.internal.ExcludeJacocoGeneratedReport

/**
 * @suppress
 */
@SuppressLint("AppCompatCustomView")
class BadgeView(context: Context, attrs: AttributeSet) : TextView(context, attrs) {

    private var badgeColor = 0
    private var badgeBg: ShapeDrawable? = null
    private var badgePosition: BadgePosition? = null
    private var badgeMarginH = 0
    private var badgeMarginV = 0
    private var isShown = false
    private var arrangeMargin = 0 // Arrange margin for small size

    @ExcludeJacocoGeneratedReport
    fun initBadgeView(parentLayoutSize: Int) {
        // Set default parameters
        badgeColor = Color.parseColor("#CCFF0000")
        badgePosition = BadgePosition.TOP_RIGHT
        var marginDefault = MARGIN
        var paddingDefault = PADDING

        // Special customization for less than 35dp
        if (parentLayoutSize > 0) {
            val density = resources.displayMetrics.density
            val dp = parentLayoutSize / density
            if (dp <= 35) {
                val ratio = if (density >= 3.0) 0.10f else 0.23f // over xdpi
                textSize = parentLayoutSize * ratio
                arrangeMargin = (parentLayoutSize * ratio).toInt()
                marginDefault = 3
                paddingDefault = 3
            }
        }
        badgeMarginH = dipToPixel(
            resources,
            marginDefault
        )
        badgeMarginV = badgeMarginH

        // Set TextView parameters
        typeface = Typeface.DEFAULT_BOLD
        val padding = dipToPixel(
            resources,
            paddingDefault
        )
        setPadding(padding, 0, padding, 0)
        setTextColor(DEFAULT_TEXT_COLOR)
        isShown = false
        visibility = View.GONE
    }

    fun show() {
        show(false, null)
    }

    fun show(paramAnimation: Animation?) {
        show(true, paramAnimation)
    }

    @SuppressLint("NewApi")
    private fun show(
        paramBoolean: Boolean,
        paramAnimation: Animation?
    ) {
        if (background == null) {
            if (badgeBg == null) {
                badgeBg = defaultBackground
            }
            background = badgeBg
        }
        applyLayoutParams()
        if (paramBoolean) {
            startAnimation(paramAnimation)
        }
        visibility = View.VISIBLE
        isShown = true
    }

    private val defaultBackground: ShapeDrawable
        get() {
            val pixel = dipToPixel(
                resources,
                8
            )
            val arrayOfFloat = floatArrayOf(
                pixel.toFloat(),
                pixel.toFloat(),
                pixel.toFloat(),
                pixel.toFloat(),
                pixel.toFloat(),
                pixel.toFloat(),
                pixel.toFloat(),
                pixel.toFloat()
            )
            val localRoundRectShape =
                RoundRectShape(arrayOfFloat, null, null)
            val localShapeDrawable =
                ShapeDrawable(localRoundRectShape)
            localShapeDrawable.paint.color = badgeColor
            return localShapeDrawable
        }

    @ExcludeJacocoGeneratedReport
    private fun applyLayoutParams() {
        val localLayoutParams =
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT
            )
        when (badgePosition) {
            BadgePosition.TOP_LEFT -> {
                localLayoutParams.gravity = Gravity.TOP or Gravity.START
                localLayoutParams.setMargins(
                    badgeMarginH + 5 - arrangeMargin,
                    badgeMarginV - arrangeMargin,
                    0,
                    0
                )
            }
            BadgePosition.TOP_RIGHT -> {
                localLayoutParams.gravity = Gravity.TOP or Gravity.END
                localLayoutParams.setMargins(
                    0,
                    badgeMarginH - arrangeMargin,
                    badgeMarginV,
                    0
                )
            }
            BadgePosition.BOTTOM_LEFT -> {
                localLayoutParams.gravity = Gravity.BOTTOM or Gravity.START
                localLayoutParams.setMargins(
                    badgeMarginH + 1,
                    0,
                    0,
                    badgeMarginV + 15 + (0.5 * arrangeMargin).toInt()
                )
            }
            BadgePosition.BOTTOM_RIGHT -> {
                localLayoutParams.gravity = Gravity.BOTTOM or Gravity.END
                localLayoutParams.setMargins(
                    0,
                    0,
                    badgeMarginH,
                    badgeMarginV + 15 + (0.5 * arrangeMargin).toInt()
                )
            }
            BadgePosition.CENTER -> {
                localLayoutParams.gravity = Gravity.CENTER
                localLayoutParams.setMargins(0, 0, 0, 0)
            }
            else -> {
            }
        }
        layoutParams = localLayoutParams
    }

    fun hide() {
        text = null
        visibility = View.INVISIBLE
        badgeBg = null
        background = null
        isShown = false
    }

    /*
     * Custom parameter methods
     * These are connector API to badge
     */
    override fun isShown(): Boolean {
        return isShown
    }

    fun setBadgePosition(position: BadgePosition?) {
        badgePosition = position
    }

    fun setBadgeMargin(horizontalMargin: Int, verticalMargin: Int) {
        badgeMarginH = horizontalMargin
        badgeMarginV = verticalMargin
    }

    fun setCount(badgeCount: Int) {
        val badgeMessage =
            if (badgeCount > MAX_COUNT) COUNT_LABEL_EXCEED_MAX else badgeCount.toString()
        text = badgeMessage
    }

    companion object {
        private const val MARGIN = 5
        private const val PADDING = 5
        private const val DEFAULT_TEXT_COLOR = -1

        private const val MAX_COUNT = 99
        private const val COUNT_LABEL_EXCEED_MAX = "99+"
    }
}