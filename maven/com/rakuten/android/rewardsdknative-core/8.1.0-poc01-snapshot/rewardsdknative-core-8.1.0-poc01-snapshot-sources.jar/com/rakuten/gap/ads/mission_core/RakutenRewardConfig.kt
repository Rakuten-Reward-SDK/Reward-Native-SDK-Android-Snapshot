package com.rakuten.gap.ads.mission_core

import com.rakuten.gap.ads.mission_core.logger.RewardSdkLog
import com.rakuten.gap.ads.mission_core.modules.singleton.RewardSDKModule
import com.rakuten.gap.ads.mission_core.resource.SupportedLocale
import com.rakuten.gap.ads.mission_core.settings.RakutenRewardSDKSettings
import com.rakuten.gap.ads.mission_core.status.RakutenRewardSDKStatus

/**
 * This class is to configure Reward SDK.
 * It's recommended to configure Reward SDK in Application class.
 */
object RakutenRewardConfig {

    private var uiEnabled: Boolean = true

    private var optedOut: Boolean = false

    /**
     * Flag to indicate this is Ichiba App
     */
    private var isIchibaApp: Boolean = false

    private var customDomain: String? = null

    private var customPath: String? = null

    private var missionEventFeatureEnabled = false

    private var appLocale: SupportedLocale? = null

    internal fun internalInit(uiEnabled: Boolean, optedOut: Boolean) {
        this.uiEnabled = uiEnabled
        this.optedOut = optedOut
    }

    /**
     * Check opted out status
     *
     * @return true - Reward SDK function does not work
     */
    @JvmStatic
    fun isOptedOut(): Boolean {
        return optedOut
    }

    /**
     * Set opted out status
     *
     * @param [optedOut] true - User is opted out from Reward Service and Reward SDK function does not work
     * @since 3.3.0
     */
    @JvmStatic
    fun setOptedOut(optedOut: Boolean) {
        this.optedOut = optedOut
        RakutenRewardSDKSettings.setRakutenRewardSDKFeatureEnabled(!optedOut)
        // If change optout is true, set offline immediately
        if (optedOut && (RakutenReward.status == RakutenRewardSDKStatus.ONLINE
                    || RakutenReward.status == RakutenRewardSDKStatus.TOKENEXPIRED)
        ) {
            RewardSDKModule.status = RakutenRewardSDKStatus.OFFLINE
        }
    }

    /**
     * Check is mission achievement notification enabled
     */
    @JvmStatic
    fun isUiEnabled(): Boolean {
        return uiEnabled
    }

    /**
     * Set mission achievement notification enable status
     *
     * @since 3.3.0
     * @param [uiEnabled]
     * true - will be notified when achieved mission<br/>
     * false - will not be notified when achieved mission
     */
    @JvmStatic
    fun setUiEnabled(uiEnabled: Boolean) {
        this.uiEnabled = uiEnabled
        RakutenRewardSDKSettings.setRakutenRewardSDKUIEnabled(uiEnabled)
    }

    /**
     * This API is only intended for Rakuten Ichiba App team
     */
    @JvmStatic
    fun isIchibaApp() = isIchibaApp

    /**
     * This API is only intended for Rakuten Ichiba App team
     */
    @JvmStatic
    fun setIsIchibaApp(flag: Boolean) {
        this.isIchibaApp = flag
    }

    /**
     * This API is only intended for Rakuten Ichiba App team
     *
     * This API is intended to configure staging URL
     */
    @JvmStatic
    fun setCustomDomain(domain: String?) {
        customDomain = domain
    }

    /**
     * This API is only intended for Rakuten Ichiba App team
     */
    @JvmStatic
    fun getCustomDomain() = customDomain

    /**
     * This API is only intended for Rakuten Ichiba App team
     *
     * This API is intended to configure staging URL
     */
    @JvmStatic
    fun setCustomPath(path: String?) {
        customPath = path
    }

    /**
     * This API is only intended for Rakuten Ichiba App team
     */
    @JvmStatic
    fun getCustomPath() = customPath

    /**
     * Check is mission event feature enabled
     */
    @JvmStatic
    fun isMissionEventFeatureEnabled() = missionEventFeatureEnabled

    /**
     * Enable or disable mission event feature
     */
    @JvmStatic
    fun setMissionEventFeatureEnabled(enabled: Boolean) {
        this.missionEventFeatureEnabled = enabled
    }

    /**
     * Rakuten Reward SDK supports multiple languages which client app may not necessarily support.
     *
     * By default the SDK will use the device locale.
     *
     * In order to have a consistent user experience, it is recommended to set the app locale
     *
     * @param supportedLocale the locale to be set for the app
     * @see SupportedLocale
     * @since 7.5.0
     */
    @JvmStatic
    fun setAppLocale(supportedLocale: SupportedLocale) {
        this.appLocale = supportedLocale
    }

    /**
     * Get the app locale that has been set for the Rakuten Reward SDK.
     *
     * By default, it will return null if not set.
     *
     * @since 7.5.0
     */
    @JvmStatic
    fun getAppLocale(): SupportedLocale? = appLocale

    private var missionDeeplinkMap: Map<String, String> = emptyMap()

    /**
     * Set a mapping of mission action codes to deeplink URLs.
     *
     * When a user taps the Challenge button on a mission in the portal,
     * the SDK will launch the corresponding deeplink URL if one is provided
     * for that mission's action code.
     *
     * ```kotlin
     * RakutenRewardConfig.setMissionDeeplinkMap(
     *     mapOf(
     *         "ACTION_CODE_A" to "myapp://shopping",
     *         "ACTION_CODE_B" to "myapp://travel"
     *     )
     * )
     * ```
     *
     * @param map A map of actionCode to deeplink URL string
     */
    @JvmStatic
    fun setMissionDeeplinkMap(map: Map<String, String>) {
        missionDeeplinkMap = map
    }

    /**
     * Get the mission deeplink map previously set via [setMissionDeeplinkMap].
     */
    @JvmStatic
    fun getMissionDeeplinkMap(): Map<String, String> = missionDeeplinkMap

    /**
     * Set Reward SDK to be debuggable and able to see SDK logs
     *
     * @since 3.1.1
     *
     * <b>Sample usage<b/>
     * ```kotlin
     * if (BuildConfig.DEBUG) {
     *      RakutenRewardConfig.isDebuggable()
     * }
     * ```
     */
    @JvmStatic
    fun isDebuggable() {
        RewardSdkLog.isDebuggable()
    }
}