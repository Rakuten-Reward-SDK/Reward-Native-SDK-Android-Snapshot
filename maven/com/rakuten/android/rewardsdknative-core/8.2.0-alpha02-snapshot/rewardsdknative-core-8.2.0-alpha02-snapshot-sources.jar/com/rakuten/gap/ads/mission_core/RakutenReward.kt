package com.rakuten.gap.ads.mission_core

import com.rakuten.gap.ads.common.logger.RewardDebugLog
import com.rakuten.gap.ads.mission_core.api.status.RakutenRewardAPIError
import com.rakuten.gap.ads.mission_core.auth.RewardTokenProvider
import com.rakuten.gap.ads.mission_core.data.MissionAchievementData
import com.rakuten.gap.ads.mission_core.data.MissionData
import com.rakuten.gap.ads.mission_core.data.MissionLiteData
import com.rakuten.gap.ads.mission_core.data.RakutenRewardAPILastCalled
import com.rakuten.gap.ads.mission_core.data.RakutenRewardPointHistory
import com.rakuten.gap.ads.mission_core.data.RakutenRewardUser
import com.rakuten.gap.ads.mission_core.data.redeem.LinkShareItemPointHistory
import com.rakuten.gap.ads.mission_core.data.redeem.RewardRedeemRequest
import com.rakuten.gap.ads.mission_core.di.ContainerProvider
import com.rakuten.gap.ads.mission_core.listeners.RakutenRewardListener
import com.rakuten.gap.ads.mission_core.modules.ModuleProvider
import com.rakuten.gap.ads.mission_core.modules.singleton.RewardSDKActivityModule
import com.rakuten.gap.ads.mission_core.modules.singleton.RewardSDKAdModule
import com.rakuten.gap.ads.mission_core.modules.singleton.RewardSDKApiInfoModule
import com.rakuten.gap.ads.mission_core.modules.singleton.RewardSDKModule
import com.rakuten.gap.ads.mission_core.settings.RakutenRewardSDKSettings
import com.rakuten.gap.ads.mission_core.status.RakutenRewardConsentStatus
import com.rakuten.gap.ads.mission_core.status.RakutenRewardSDKStatus
import com.rakuten.gap.ads.mission_core.status.RakutenRewardTokentype

/**
 * This class contain the main settings and API of Reward SDK
 */
object RakutenReward {

    /**
     * Reward SDK Application Key
     *
     * Set the Application Key in `AndroidManifest.xml`
     * ```
     * <meta-data android:name="com.rakuten.gap.ads.mission_core.appKey"
     *      android:value="{Application Key}"/>
     * ```
     */
    var appCode: String = ""
        get() = RewardSDKApiInfoModule.getAppCode()
        private set

    /**
     * Reward SDK status
     */
    var status: RakutenRewardSDKStatus = RakutenRewardSDKStatus.OFFLINE
        get() = RewardSDKModule.status
        private set

    /**
     * Reward SDK Version
     */
    val version: String by lazy {
        RewardSDKModule.VERSION
    }

    /**
     * Switch ID Solution
     */
    var tokenType: RakutenRewardTokentype
        get() = RewardSDKModule.tokenType
        set(value) {
            RewardSDKModule.tokenType = value
        }

    /**
     * The last failed API call
     */
    var lastFailed: RakutenRewardAPILastCalled? = null
        get() = RewardSDKModule.lastFailed
        private set

    /**
     * User Data
     */
    var user: RakutenRewardUser = RakutenRewardUser()
        get() = RewardSDKModule.user
        private set

    /**
     *  Event Listener
     *
     *  This variable is deprecated since 3.1.0. Please use [RakutenReward.addRakutenRewardListener]
     */
    @Deprecated(
        message = "Please use RakutenReward.addRakutenRewardListener instead.",
        replaceWith = ReplaceWith("RakutenReward.addRakutenRewardListener(listener)"),
        level = DeprecationLevel.ERROR
    )
    var listener: RakutenRewardListener? = null

    // This is use for Rakuten Internal
    /**
     * Initialize Reward SDK with token and appCode
     *
     * This API is deprecated since 3.3.0.
     *
     * Please set the Application Key in `AndroidManifest.xml`
     * ```xml
     * <meta-data android:name="com.rakuten.gap.ads.mission_core.appKey"
     *      android:value="{Application Key}"/>
     * ```
     *
     * @param [appCode] Application Key (This is from Rakuten Reward Developer Portal)
     * @param [token] User access token
     */
    @Deprecated(
        message = "Please set the AppKey in AndroidManifest",
        level = DeprecationLevel.WARNING
    )
    @JvmStatic
    fun init(appCode: String, token: String) {
        RewardSDKApiInfoModule.setAppCode(appCode)
        RewardSDKModule.setAccessToken(token, RewardSDKModule.tokenType)
    }

    /**
     * Initialize Reward SDK with token and appCode
     *
     * Please set the Application Key in `AndroidManifest.xml`
     * ```xml
     * <meta-data android:name="com.rakuten.gap.ads.mission_core.appKey"
     *      android:value="{Application Key}"/>
     * ```
     *
     * @param [appCode] Application Key (This is from Rakuten Reward Developer Portal)
     * @param [rewardTokenProvider] Implementation of [RewardTokenProvider] to provide access token
     */
    @JvmStatic
    fun init(appCode: String, rewardTokenProvider: RewardTokenProvider) {
        RewardSDKApiInfoModule.setAppCode(appCode)
        RewardSDKModule.rewardTokenProvider = rewardTokenProvider
    }

    /**
     * Initialize Reward SDK with [RewardTokenProvider]
     *
     * ```kotlin
     * RakutenReward.init(object : RewardTokenProvider {
     *   override suspend fun getAccessToken(): String {
     *      // Return the token here
     *   }
     * })
     * ```
     *
     *
     * @param [rewardTokenProvider] Implementation of [RewardTokenProvider] to provide access token
     */
    @JvmStatic
    fun init(rewardTokenProvider: RewardTokenProvider) {
        RewardSDKModule.rewardTokenProvider = rewardTokenProvider
    }

    // This is for Rakuten External
    /**
     * Initialize Reward SDK with appCode
     *
     * Please set the Application Key in `AndroidManifest.xml`
     * ```xml
     * <meta-data android:name="com.rakuten.gap.ads.mission_core.appKey"
     *      android:value="{Application Key}"/>
     * ```
     *
     * @param [appCode] Application Key (This is from Rakuten Reward Developer Portal)
     */
    @JvmStatic
    fun init(appCode: String) {
        RewardDebugLog.d("RakutenReward", "initialize with AppCode [$appCode]")
        RewardSDKApiInfoModule.setAppCode(appCode)
        RakutenRewardConfig.internalInit(
            RakutenRewardSDKSettings.isRakutenRewardSDKUIEnabled(),
            !RakutenRewardSDKSettings.isRakutenRewardSDKFeatureEnabled()
        )
    }

    /**
     * Set RID token
     *
     * This method is deprecated and will be removed in future release.
     *
     * Please use [RakutenReward.init] to provide the token and [RakutenReward.tokenType] to set the token type.
     *
     * ```kotlin
     * RakutenReward.tokenType = RakutenRewardTokentype.RID
     *
     * RakutenReward.init(object : RewardTokenProvider {
     *   override suspend fun getAccessToken(): String {
     *      // Return the token here
     *   }
     * })
     * ```
     */
    @Deprecated(
        message = "This method is deprecated and will be removed in future release. Please use RakutenReward.init(appCode: String, rewardTokenProvider: RewardTokenProvider) to provide the token.",
        replaceWith = ReplaceWith("RakutenReward.init(rewardTokenProvider)"),
        level = DeprecationLevel.WARNING
    )
    @JvmStatic
    fun setRIdToken(token: String) {
        RewardSDKModule.setAccessToken(token, RakutenRewardTokentype.RID)
    }

    /**
     * Set RAE token
     */
    @Deprecated(
        message = "RAE will be abolished by 2025. Please make a plan to migrate to RID token or other solution. This API will be removed in future release.",
        replaceWith = ReplaceWith("RakutenReward.setRIdToken(token)"),
        level = DeprecationLevel.WARNING
    )
    @JvmStatic
    fun setRaeToken(token: String) {
        RewardSDKModule.setAccessToken(token, RakutenRewardTokentype.RAE)
    }

    /**
     * Clear access token
     */
    @JvmStatic
    fun clearAccessToken() {
        RewardSDKModule.clearAccessToken()
    }

    /**
     * Add Event listener
     *
     * <mark>If this method is used in Activity or Fragment class, [RakutenReward.removeRakutenRewardListener]
     * should be called whenever Activity class is destroyed to prevent memory leak. </mark>
     *
     * @param [listener] RakutenRewardListener
     * @since 3.1.0
     * @see [RakutenReward.removeRakutenRewardListener]
     */
    @JvmStatic
    fun addRakutenRewardListener(listener: RakutenRewardListener) {
        RewardSDKModule.addRakutenRewardListener(listener)
    }

    /**
     * Remove Event listener
     *
     * @param [listener] RakutenRewardListener
     * @since 3.1.0
     */
    @JvmStatic
    fun removeRakutenRewardListener(listener: RakutenRewardListener) {
        RewardSDKModule.removeRakutenRewardListener(listener)
    }

    /**
     * Start SDK session.
     *
     * The session has been handled by SDK using Activity lifecycle in [RakutenRewardLifecycle].
     * This API is to manually trigger to start the SDK session.
     *
     * @since 3.4.2
     */
    @JvmStatic
    fun startSession() {
        if (RakutenRewardConfig.isOptedOut()) {
            RewardDebugLog.d("RakutenReward", "Reward feature is opted out, startSession is ignored.")
            return
        }
        memberInfo({}) {}
    }

    /**
     * Open Rakuten Reward Help Page
     */
    @JvmStatic
    fun openHelpPage() {
        RewardSDKActivityModule.openHelpPage()
    }

    /**
     * Open Rakuten Reward T&C Page
     */
    @JvmStatic
    fun openTCPage() {
        RewardSDKActivityModule.openTCPage()
    }

    /**
     * Open Rakuten Reward Privacy Policy Page
     */
    @JvmStatic
    fun openPrivacyPage() {
        RewardSDKActivityModule.openPrivacyPage()
    }

    /**
     * Get the latest member info
     *
     * @param [success] Success callback, return [RakutenRewardUser]
     * @param [failed] Failure callback
     */
    @JvmStatic
    fun memberInfo(
        success: (sdkuser: RakutenRewardUser) -> Unit,
        failed: (e: RakutenRewardAPIError) -> Unit
    ) {
        getModuleProvider().provideMembersModule().memberInfo(success, failed)
    }

    /**
     * Get the mission list
     *
     * @param [success] Success callback, return a list of [MissionData]
     * @param [failed] Failure callback
     */
    @JvmStatic
    fun getMissions(
        success: (missions: List<MissionData>) -> Unit,
        failed: (e: RakutenRewardAPIError) -> Unit
    ) {
        getModuleProvider().provideMissionModule().getMissionList(success, failed)
    }

    /**
     * Get the mission list in lite version.
     * Lite version of mission data only contain the necessary information for the mission.
     * It does not contain the progress of the mission.
     *
     * @param [success] Success callback, return a list of [MissionLiteData]
     * @param [failed] Failure callback
     *
     * @since 6.1.0
     */
    @JvmStatic
    fun getMissionsLite(
        success: (missions: List<MissionLiteData>) -> Unit,
        failed: (e: RakutenRewardAPIError) -> Unit
    ) {
        getModuleProvider().provideMissionModule().getMissionLite(success, failed)
    }

    /**
     * Get the mission details
     *
     * @param [actionCode] The action code of the mission
     * @param [success] Success callback, return a list of [MissionData]
     * @param [failed] Failure callback
     *
     * @since 6.1.0
     */
    @JvmStatic
    fun getMissionDetails(
        actionCode: String,
        success: (missions: MissionData) -> Unit,
        failed: (e: RakutenRewardAPIError) -> Unit
    ) {
        getModuleProvider().provideMissionModule().getMissionDetails(actionCode, success, failed)
    }

    /**
     * Log a mission action
     *
     * @param [actionCode] The action code of the mission
     * @param [success] Success callback
     * @param [failed] Failure callback
     */
    @JvmStatic
    fun logAction(
        actionCode: String,
        success: () -> Unit,
        failed: (e: RakutenRewardAPIError) -> Unit
    ) {
        getModuleProvider().provideMissionModule().logAction(actionCode, success, failed)
    }

    /**
     * Get the list of unclaimed items
     *
     * @param [success] Success callback, return a list of unclaimed [MissionAchievementData]
     * @param [failed] Failure callback
     */
    @JvmStatic
    fun getUnclaimedItems(
        success: (missions: List<MissionAchievementData>) -> Unit,
        failed: (e: RakutenRewardAPIError) -> Unit
    ) {
        getModuleProvider().provideUnclaimModule().getUnclaim(success, failed)
    }

    /**
     * Get user's last 3 months point history
     *
     * @param [success] Success callback, return [RakutenRewardPointHistory]
     * @param [failed] Failure callback
     */
    @JvmStatic
    fun getPointHistory(
        success: (pointHistory: RakutenRewardPointHistory) -> Unit,
        failed: (e: RakutenRewardAPIError) -> Unit
    ) {
        getModuleProvider().providePointModule().pointHistory(success, failed)
    }

    /**
     * User provide consent
     *
     * @param [success] Success callback
     * @param [failed] Failure Callback
     */
    internal fun provideConsent(
        success: (status: Boolean) -> Unit,
        failed: (e: RakutenRewardAPIError) -> Unit
    ) {
        getModuleProvider().provideConsentModule().provideConsent(success, failed)
    }

    /**
     * Set Rp cookie
     */
    @JvmStatic
    fun setRp(rp: String) {
        RewardSDKAdModule.cachedRp = rp
    }

    /**
     * Set Rz cookie
     */
    @JvmStatic
    fun setRz(rz: String) {
        RewardSDKAdModule.cachedRz = rz
    }

    /**
     * Set Ra cookie
     *
     * @since 4.1.0
     */
    @JvmStatic
    fun setRa(ra: String) {
        RewardSDKAdModule.cachedRa = ra
    }

    /**
     * Close claim UI forcibly
     */
    @JvmStatic
    fun forceClaimClose() {
        RewardSDKActivityModule.forceClose()
    }

    /**
     * Request for Consent if the user have not provide consent.
     *
     * If user have not provide consent, Consent Dialog will be shown to ask for user's consent.
     * Else the callback will be trigger immediately  with [RakutenRewardConsentStatus.CONSENT_PROVIDED] status.
     *
     * The consent dialog can only be dismissed when user click on the buttons
     * and the consent status will be returned in the callback.
     *
     * ```kotlin
     * RakutenReward.requestForConsent { status ->
     *      if (status == RakutenRewardConsentStatus.CONSENT_PROVIDED) {
     *          // trigger action when status is CONSENT_PROVIDED
     *          RakutenReward.logAction("actioncode")
     *      }
     * }
     * ```
     *
     * @param [requestConsentCallback] Callback to return [RakutenRewardConsentStatus]
     *
     * @since 4.0.0
     */
    @JvmStatic
    fun requestForConsent(requestConsentCallback: ((RakutenRewardConsentStatus) -> Unit)? = null) {
        RewardSDKActivityModule.requestForConsent(requestConsentCallback)
    }

    /**
     * Show a notification banner if user haven't provide consent.
     *
     * ```kotlin
     * RakutenReward.showConsentBanner { status ->
     *      if (status == RakutenRewardConsentStatus.CONSENT_PROVIDED) {
     *          // trigger action when status is CONSENT_PROVIDED
     *          RakutenReward.logAction("actioncode")
     *      }
     * }
     * ```
     *
     * @param [requestConsentCallback] Callback to return [RakutenRewardConsentStatus]
     *
     * @since 5.3.0
     */
    @JvmStatic
    fun showConsentBanner(requestConsentCallback: ((RakutenRewardConsentStatus) -> Unit)? = null) {
        RewardSDKActivityModule.showConsentBanner(requestConsentCallback)
    }


    @JvmStatic
    fun getLSPointHistory(
        redeemRequest: RewardRedeemRequest,
        offset: Int,
        limit: Int,
        success: (pointHistory: LinkShareItemPointHistory) -> Unit,
        failed: (e: RakutenRewardAPIError) -> Unit
    ) {
        getModuleProvider().provideRedeemModule()
            .getLinkSharePointHistory(redeemRequest, "", offset, limit, success, failed)
    }

    /**
     * Get LinkShare item point history by status
     *
     * @param redeemRequest The redeem request information
     * @param status The status filter for point history - "PROCESSING", "SUCCESS"
     * @param offset The offset for pagination
     * @param limit The limit for pagination
     * @return [LinkShareItemPointHistory] for success case
     */
    @JvmStatic
    fun getLSPointHistoryByStatus(
        redeemRequest: RewardRedeemRequest,
        status: String,
        offset: Int,
        limit: Int,
        success: (pointHistory: LinkShareItemPointHistory) -> Unit,
        failed: (e: RakutenRewardAPIError) -> Unit
    ) {
        getModuleProvider().provideRedeemModule()
            .getLinkSharePointHistory(redeemRequest, status, offset, limit, success, failed)
    }

    @JvmStatic
    fun getLSProcessingPoint(
        redeemRequest: RewardRedeemRequest,
        success: (points: Int) -> Unit,
        failed: (e: RakutenRewardAPIError) -> Unit
    ) {
        getModuleProvider().provideRedeemModule()
            .getLinkShareProcessingPoint(redeemRequest, success, failed)
    }

    private fun getModuleProvider(): ModuleProvider {
        return ContainerProvider.getAppContainer().getProvider(ModuleProvider::class.java)
    }
}