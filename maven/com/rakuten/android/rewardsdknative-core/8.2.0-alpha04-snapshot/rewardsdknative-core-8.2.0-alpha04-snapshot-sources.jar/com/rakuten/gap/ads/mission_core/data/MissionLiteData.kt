package com.rakuten.gap.ads.mission_core.data

/**
 * This is Reward SDK Mission Lite data.
 */
data class MissionLiteData(
    /**
     * Mission Name
     */
    val name: String?,
    /**
     * Action Code
     */
    val actionCode: String?,
    /**
     * Mission Icon URL
     */
    val iconurl: String?,
    /**
     * Mission Instruction
     */
    val instruction: String?,
    /**
     * Mission Condition
     */
    val condition: String?,
    /**
     * Mission Notification Type. The only possible value: NONE, BANNER, MODAL, CUSTOM
     */
    val notificationtype: String?,
    /**
     * Mission Point
     */
    val point: Int,
    /**
     * Mission End Date in yyyyMMdd format
     */
    val enddatestr: String?,
    /**
     * Number of days left of the mission. Can be null.
     * <b>Example value</b>
     * 残り3日
     */
    val till: String?,
    /**
     * Extension data for mission
     */
    val ext: MutableMap<String, String>,
    /**
     * Number of required action times
     */
    val times: Int
) {

    /**
     * @suppress
     */
    fun addExtra(key: String, value: String?) {
        value?.let { ext.put(key, it) }
    }
}
