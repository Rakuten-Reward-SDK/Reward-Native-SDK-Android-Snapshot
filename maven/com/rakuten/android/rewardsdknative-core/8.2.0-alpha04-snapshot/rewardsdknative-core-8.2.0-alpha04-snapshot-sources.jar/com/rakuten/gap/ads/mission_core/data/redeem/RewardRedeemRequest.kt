package com.rakuten.gap.ads.mission_core.data.redeem

/**
 *
 * @author zack.keng
 * Created on 2025/12/04
 * Copyright © 2025 Rakuten Asia. All rights reserved.
 */
data class RewardRedeemRequest(
    val tenantId: String,
    val appName: String
)
