package com.rakuten.gap.ads.mission_core.ui.claim

/**
 * MissionClaimViewEvent sealed class.
 */
sealed class MissionClaimViewEvent

/**
 * DismissByUser event type.
 *
 * This event type will be return whenever:
 * - When user click on X button to close the claim view
 * - when user click on the grey region to dismiss the claim view
 * - when user press back to dismiss the claim view
 */
object DismissByUser : MissionClaimViewEvent()

/**
 * TriggerIchibaDeeplink event type
 *
 * This event type will be return whenever user click on the ad and RPP deeplink URL is formed
 *
 * @param [deeplinkUrl] RPP deeplink URL
 */
data class TriggerIchibaDeeplink(val deeplinkUrl: String) : MissionClaimViewEvent()
