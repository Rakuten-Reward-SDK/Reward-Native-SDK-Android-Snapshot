package com.rakuten.gap.ads.mission_core.api.status

/**
 * Claim point status
 */
enum class RakutenRewardClaimStatus {
    /**
     * Claim event not yet started
     */
    NOTYET,

    /**
     * Claim successfully
     */
    SUCCESS,

    /**
     * Failed to claim
     */
    FAIL
}