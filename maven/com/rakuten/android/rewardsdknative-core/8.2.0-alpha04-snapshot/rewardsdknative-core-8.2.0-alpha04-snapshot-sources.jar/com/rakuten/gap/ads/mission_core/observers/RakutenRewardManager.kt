@file:Suppress("unused")

package com.rakuten.gap.ads.mission_core.observers

import android.app.Activity
import androidx.lifecycle.*
import com.rakuten.gap.ads.mission_core.di.ContainerProvider
import com.rakuten.gap.ads.mission_core.di.provider.CoroutineProvider
import com.rakuten.gap.ads.mission_core.internal.ExcludeJacocoGeneratedReport
import com.rakuten.gap.ads.mission_core.modules.singleton.RewardSDKActivityModule
import java.lang.ref.WeakReference

/**
 * This class uses AndroidX lifecycle-aware components
 */
class RakutenRewardManager {

    companion object {
        /**
         * Bind Activity class to Reward SDK's LifecycleObserver
         *
         * <b>Sample usage</b>
         * ```kotlin
         * class SampleActivity: AppCompatActivity() {
         *
         *      override fun onCreate(savedInstanceState: Bundle?) {
         *          super.onCreate(savedInstanceState)
         *          RakutenRewardManager.bindRakutenRewardIn(this, this)
         *      }
         * }
         * ```
         */
        fun bindRakutenRewardIn(lifecycleOwner: LifecycleOwner, activity: Activity) {
            RakutenRewardObserver(activity, lifecycleOwner)
        }

        @ExcludeJacocoGeneratedReport
        class RakutenRewardObserver(
            activity: Activity,
            private val lifecycleOwner: LifecycleOwner
        ) : LifecycleObserver {

            private var current: WeakReference<Activity> = WeakReference(activity)

            init {
                lifecycleOwner.lifecycle.addObserver(this)
                ContainerProvider.getAppContainer().getProvider(CoroutineProvider::class.java)
                    .setCoroutineScope(lifecycleOwner.lifecycleScope)
            }

            @OnLifecycleEvent(Lifecycle.Event.ON_CREATE)
            fun onCreate() {
                current.get()?.let {
                    RewardSDKActivityModule.onActivityCreate(it)
                }
            }

            @OnLifecycleEvent(Lifecycle.Event.ON_START)
            fun onStart() {
                ContainerProvider.getAppContainer().getProvider(CoroutineProvider::class.java)
                    .setCoroutineScope(lifecycleOwner.lifecycleScope)
                RewardSDKActivityModule.onActivityStart(current.get())
            }

            @OnLifecycleEvent(Lifecycle.Event.ON_DESTROY)
            fun onDestroy() {
                RewardSDKActivityModule.onActivityDestroy()
            }

            @OnLifecycleEvent(Lifecycle.Event.ON_RESUME)
            fun onResume() {
                RewardSDKActivityModule.onActivityResume(current.get())
            }
        }
    }
}