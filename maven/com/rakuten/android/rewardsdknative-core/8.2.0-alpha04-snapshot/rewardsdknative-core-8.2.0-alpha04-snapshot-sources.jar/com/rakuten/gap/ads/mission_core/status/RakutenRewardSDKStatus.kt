package com.rakuten.gap.ads.mission_core.status

/**
 * Rakuten Reward SDK Status
 */
enum class RakutenRewardSDKStatus {
    /**
     * SDK is ready
     */
    ONLINE,

    /**
     * SDK is not ready. Initialization API failed
     */
    OFFLINE,

    /**
     * Application Key is invalid.
     */
    APPCODEINVALID,

    /**
     * Token has expired.
     */
    TOKENEXPIRED,

    /**
     * User haven't provide consent to Reward SDK
     *
     * @since 4.0.0
     */
    USER_NOT_CONSENT
}