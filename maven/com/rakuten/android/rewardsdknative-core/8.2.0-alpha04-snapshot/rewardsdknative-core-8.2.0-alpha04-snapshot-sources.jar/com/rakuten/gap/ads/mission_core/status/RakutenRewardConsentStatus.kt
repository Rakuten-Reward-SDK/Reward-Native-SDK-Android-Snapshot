package com.rakuten.gap.ads.mission_core.status

/**
 * User consent status
 *
 * @author zack.keng
 * Created on 2023/05/04
 *
 * @since 4.0.0
 */
enum class RakutenRewardConsentStatus {

    /**
     * User provided consent
     */
    CONSENT_PROVIDED,

    /**
     * User did not provide consent
     */
    CONSENT_NOT_PROVIDED,

    /**
     * User provide consent but API failed
     */
    CONSENT_FAILED,

    /**
     * User provided consent but failed to restart session
     */
    CONSENT_PROVIDED_RESTART_SESSION_FAILED
}
