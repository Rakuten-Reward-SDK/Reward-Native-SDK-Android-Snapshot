@file:Suppress("unused")

package com.rakuten.gap.ads.mission_core

import android.app.Activity
import android.content.Intent
import androidx.activity.result.ActivityResult
import androidx.activity.result.ActivityResultCallback
import androidx.fragment.app.Fragment
import com.rakuten.gap.ads.mission_core.RakutenAuth.handleActivityResult
import com.rakuten.gap.ads.mission_core.api.status.RakutenRewardAPIError
import com.rakuten.gap.ads.mission_core.data.RakutenAuthUserInfo
import com.rakuten.gap.ads.mission_core.di.ContainerProvider
import com.rakuten.gap.ads.mission_core.listeners.LoginResultCallback
import com.rakuten.gap.ads.mission_core.listeners.LogoutResultCallback
import com.rakuten.gap.ads.mission_core.modules.AuthModule
import com.rakuten.gap.ads.mission_core.modules.MembersModule
import com.rakuten.gap.ads.mission_core.modules.ModuleProvider
import com.rakuten.gap.ads.mission_core.modules.singleton.RewardSDKModule
import com.rakuten.gap.ads.mission_core.status.RakutenRewardTokentype

/**
 * This class contain the API for [RakutenRewardTokentype.RAKUTEN_AUTH] login options
 */
object RakutenAuth {

    /**
     * Check if user has signed in
     *
     * @return
     * true - user has signed in<br/>
     * false - user is not signed in
     */
    @JvmStatic
    fun hasUserSignedIn(): Boolean {
        return getAuthModule().hasUserSignedIn()
    }

    /**
     * Start login page in WebView to retrieve tokens
     *
     * @param [activity] the Activity instance
     * @param [requestCode] Unique request code to receive callback in [Activity.onActivityResult]
     *
     * <b>Call [handleActivityResult] once onActivityResult is triggered</b>
     *
     * ```kotlin
     * RakutenAuth.openLoginPage(this, 100)
     *
     * override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
     *      if (requestCode == 100 && resultCode == RESULT_OK) {
     *          RakutenAuth.handleActivityResult(data, callback)
     *     }
     * }
     * ```
     *
     * @see [handleActivityResult]
     */
    @JvmStatic
    fun openLoginPage(activity: Activity, requestCode: Int) {
        getAuthModule().loginWith3rdParty(activity, requestCode)
    }

    /**
     * Start login page in WebView to retrieve tokens. This uses AndroidX Activity Result API.
     *
     * @param [activity] the Activity instance
     * @param [callback] ActivityResultCallback to get ActivityResult
     *
     * <b>Call [handleActivityResult] in the callback</b>
     *
     * ```kotlin
     * RakutenAuth.openLoginPage(this) { result ->
     *      if (result.resultCode == RESULT_OK) {
     *          RakutenAuth.handleActivityResult(result.data, callback)
     *      }
     * }
     * ```
     *
     * @see [handleActivityResult]
     * @since v3.4.2
     */
    @JvmStatic
    fun openLoginPage(activity: Activity, callback: ActivityResultCallback<ActivityResult>) {
        getAuthModule().loginWith3rdParty(activity, callback)
    }

    /**
     * Start login page in WebView to retrieve tokens
     *
     * @param [fragment] the Fragment instance
     * @param [requestCode] Unique request code to receive callback in [Fragment.onActivityResult]
     *
     * <b>Call [handleActivityResult] once onActivityResult is triggered</b>
     *
     * ```kotlin
     * RakutenAuth.openLoginPage(this, 100)
     *
     * override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
     *      if (requestCode == 100 && resultCode == RESULT_OK) {
     *          RakutenAuth.handleActivityResult(data, callback)
     *     }
     * }
     * ```
     *
     * @see [handleActivityResult]
     * @since v2.4.1
     */
    @JvmStatic
    fun openLoginPage(fragment: Fragment, requestCode: Int) {
        getAuthModule().loginWith3rdParty(fragment, requestCode)
    }

    /**
     * get activity result from webview activity<br/>
     * register callback to get login result
     *
     * @param [data] The Intent data from onActivityResult
     * @param [callback] LoginResultCallback instance to get login result
     *
     * @see [LoginResultCallback]
     */
    @JvmStatic
    fun handleActivityResult(data: Intent?, callback: LoginResultCallback) {
        getAuthModule().handleActivityResult(data, object : LoginResultCallback {
            override fun loginSuccess() {
                // get member info after login
                RewardSDKModule.setDefaultTokenProvider()
                getMembersModule().memberInfo({
                    callback.loginSuccess()
                }) {
                    callback.loginFailed(it)
                }
            }

            override fun loginFailed(e: RakutenRewardAPIError) {
                callback.loginFailed(e)
            }
        })
    }

    /**
     * logout user
     *
     * @param [callback] LogoutResultCallback instance to get logout result
     *
     * @see [LogoutResultCallback]
     */
    @JvmStatic
    fun logout(callback: LogoutResultCallback) = getAuthModule().logout(callback)

    /**
     * Get Rakuten Member name
     *
     * @since version 3.3.0
     */
    @JvmStatic
    fun getUserName(): String = getAuthModule().getUserName()

    /**
     * Get user latest Rakuten Points and Rank
     *
     * <mark>For application in JAVA code, please use RakutenRewardJava.getUserInfoJava</mark>
     *
     * @param success Success callback, return [RakutenAuthUserInfo]
     * @param failed Failure callback, return [RakutenRewardAPIError]
     *
     */
    @JvmStatic
    fun getUserInfo(
        success: (userInfo: RakutenAuthUserInfo) -> Unit,
        failed: (e: RakutenRewardAPIError) -> Unit
    ) {
        ContainerProvider.getAppContainer().getProvider(ModuleProvider::class.java)
            .provideMembersModule().rakutenAuthMemberInfo(success, failed)
    }


    @JvmStatic
    suspend fun getUserInfo(): RewardApiResult<RakutenAuthUserInfo> =
        ContainerProvider.getAppContainer().getProvider(ModuleProvider::class.java)
            .provideMembersCoroutineModule().rakutenAuthMemberInfo()

    private fun getAuthModule(): AuthModule {
        return ContainerProvider.getAppContainer().getProvider(ModuleProvider::class.java)
            .provideAuthModule()
    }

    private fun getMembersModule(): MembersModule =
        ContainerProvider.getAppContainer().getProvider(ModuleProvider::class.java)
            .provideMembersModule()
}