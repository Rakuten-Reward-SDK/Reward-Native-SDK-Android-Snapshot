package com.rakuten.gap.ads.mission_core.api.status

/**
 * Error Response code list
 */
enum class RakutenRewardAPIError {
    /**
     * Network connection error
     */
    NETWORKERROR,                      // Failed to connect

    /**
     * Parameter is invalid
     */
    INVALIDREQUEST,                    // Log Action Bad Request

    /**
     * Access token is not set
     */
    TOKENEMPTY,                        // Token is empty

    /**
     * SDK is not initialized yet
     */
    SDKNOTACTIVE,                      // SDK is not online or token expire

    /**
     * Access token has expired. Need to refresh the token.
     */
    TOKENEXPIRE,                       // Token expire

    /**
     * Application Key is invalid
     */
    APPCODEINVLID,                     // Application Code is invalid

    /**
     * User Haven't Provide Consent
     */
    USER_NOT_CONSENT,

    /**
     * Unknown error
     */
    UNKNOWN,                           // Unknown Error

    /**
     * API not support
     */
    NOTSUPPORT,                         // Not Support

    /**
     * The mission already reached cap, can't post mission action anymore
     */
    MISSION_REACHED_CAP,

    /**
     * The feature is under maintenance
     */
    UNDER_MAINTENANCE,                  // Under Maintenance
}