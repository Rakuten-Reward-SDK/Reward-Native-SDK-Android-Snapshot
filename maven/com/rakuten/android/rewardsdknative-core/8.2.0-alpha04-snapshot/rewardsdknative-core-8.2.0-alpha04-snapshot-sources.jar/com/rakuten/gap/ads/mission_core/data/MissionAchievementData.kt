@file:Suppress("unused")

package com.rakuten.gap.ads.mission_core.data

import com.rakuten.gap.ads.mission_core.Failed
import com.rakuten.gap.ads.mission_core.RakutenReward
import com.rakuten.gap.ads.mission_core.RakutenRewardCoroutine
import com.rakuten.gap.ads.mission_core.RewardApiResult
import com.rakuten.gap.ads.mission_core.api.status.RakutenRewardAPIError
import com.rakuten.gap.ads.mission_core.di.ContainerProvider
import com.rakuten.gap.ads.mission_core.internal.EventNames
import com.rakuten.gap.ads.mission_core.internal.SdkCallback
import com.rakuten.gap.ads.mission_core.internal.SdkModuleApi
import com.rakuten.gap.ads.mission_core.listeners.PreClaimCallback
import com.rakuten.gap.ads.mission_core.logger.RewardSdkLog
import com.rakuten.gap.ads.mission_core.modules.ModuleProvider
import com.rakuten.gap.ads.mission_core.status.RakutenRewardConsentStatus
import com.rakuten.gap.ads.mission_core.ui.claim.MissionClaimViewEvent
import java.util.Date

/**
 * Mission Achievement Data.<br/>
 * This is for Mission Unclaim data (after mission achieved, or unclaim mission list)
 */
data class MissionAchievementData(
    /**
     * Mission Name
     */
    val name: String?,
    /**
     * Mission Icon URL
     */
    val iconurl: String?,
    /**
     * Mission Instruction
     */
    val instruction: String?,
    /**
     * Action Code
     */
    val action: String?,
    /**
     * Flag to indicate whether notification is custom or not
     */
    val custom: Boolean,
    /**
     * Mission Notification Type. The only possible value: NONE, BANNER, MODAL, CUSTOM
     */
    val notificationtype: String?,
    /**
     * Mission Point
     */
    val point: Int?,
    /**
     * Number of unclaimed items
     */
    val unclaimed: Int?,
    /**
     * Mission Achieved Date
     */
    val achievedDate: Date?
) {
    /**
     * @suppress
     */
    companion object {
        internal fun createBlankData(): MissionAchievementData {
            return MissionAchievementData(
                null, null, null, null, false, null, null, null, null
            )
        }

        private fun getModuleProvider(): ModuleProvider =
            ContainerProvider.getAppContainer().getProvider(ModuleProvider::class.java)

        private fun claim(
            data: MissionAchievementData,
            success: (mission: MissionAchievementData) -> Unit,
            failed: (e: RakutenRewardAPIError) -> Unit,
            eventCallback: ((MissionClaimViewEvent) -> Unit)?
        ) {
            if (data.action != null && data.achievedDate != null) {
                RakutenReward.requestForConsent {
                    if (it == RakutenRewardConsentStatus.CONSENT_PROVIDED) {
                        getModuleProvider().provideUnclaimModule()
                            .claim(data, success, failed, eventCallback)
                    } else {
                        failed.invoke(RakutenRewardAPIError.USER_NOT_CONSENT)
                    }
                }
            } else {
                RewardSdkLog.w("Action code or achieved date are null. Unable to claim.")
                failed.invoke(RakutenRewardAPIError.INVALIDREQUEST)
            }
        }

        private suspend fun claim(
            data: MissionAchievementData,
            eventCallback: ((MissionClaimViewEvent) -> Unit)?
        ): RewardApiResult<MissionAchievementData> {
            return if (data.action != null && data.achievedDate != null) {
                val status = RakutenRewardCoroutine.requestForConsent()
                if (status == RakutenRewardConsentStatus.CONSENT_PROVIDED) {
                    getModuleProvider().provideUnclaimCoroutineModule().claim(data, eventCallback)
                } else {
                    Failed(RakutenRewardAPIError.USER_NOT_CONSENT)
                }
            } else {
                RewardSdkLog.w("Action code or achieved date are null. Unable to claim.")
                Failed(RakutenRewardAPIError.INVALIDREQUEST)
            }
        }
    }

    /* Public API*/
    /**
     * Claim Point API. Claim view will be displayed to show the claim status
     *
     * <mark>For application in JAVA code, please use [MissionAchievementData.claimJava]</mark>
     *
     * @param [success] Success callback
     * @param [failed] Failure callback
     *
     * <b>Since v4.0.0, User Consent feature is integrated into SDK.</b>
     *
     * If user have not provide consent yet, [RakutenReward.requestForConsent] API will be called to request for user's consent.
     * Once user provided consent will proceed claim action.
     *
     */
    fun claim(
        success: (missionData: MissionAchievementData) -> Unit,
        failed: (e: RakutenRewardAPIError) -> Unit
    ) {
        claim(success, failed, null)
    }

    /**
     * Claim Point API. Claim view will be displayed to show the claim status<br/>
     * <mark>This API is only intended for Rakuten Ichiba App team</mark>
     *
     * @param [success] Success callback
     * @param [failed] Failure callback
     * @param [eventCallback] Claim view event callback
     *
     * <b>Since v4.0.0, User Consent feature is integrated into SDK.</b>
     *
     * If user have not provide consent yet, [RakutenReward.requestForConsent] API will be called to request for user's consent.
     * Once user provided consent will proceed claim action.
     *
     */
    fun claim(
        success: (mission: MissionAchievementData) -> Unit,
        failed: (e: RakutenRewardAPIError) -> Unit,
        eventCallback: ((MissionClaimViewEvent) -> Unit)?
    ) {
        if (SdkCallback.preClaimListener == null) {
            proceedClaim(success, failed, eventCallback)
        } else {
            SdkCallback.preClaimListener?.invoke(object : PreClaimCallback {
                override fun proceedClaim() {
                    proceedClaim(success, failed, eventCallback)
                }
            })
        }
    }

    private fun proceedClaim(
        success: (mission: MissionAchievementData) -> Unit,
        failed: (e: RakutenRewardAPIError) -> Unit,
        eventCallback: ((MissionClaimViewEvent) -> Unit)?
    ) {
        val eventItem = EventItem.createItem(EventNames.CLAIM_POINT).apply {
            addExtra(EventNames.EXTRA_FROM, EventNames.getNotificationFromValue(notificationtype))
        }
        SdkModuleApi.sendEvent(eventItem)
        // Start Claim Flow
        val missionData: MissionAchievementData = this.copy()
        claim(missionData, success, failed, eventCallback)
    }

    /**
     * Claim Point API. Claim view will be displayed to show the claim status
     *
     * <b>Since v4.0.0, User Consent feature is integrated into SDK.</b>
     *
     * If user have not provide consent yet, [RakutenReward.requestForConsent] API will be called to request for user's consent.
     * Once user provided consent will proceed claim action.
     *
     */
    suspend fun claim(): RewardApiResult<MissionAchievementData> = claim(null)

    /**
     * Claim Point API. Claim view will be displayed to show the claim status<br/>
     * <mark>This API is only intended for Rakuten Ichiba App team</mark>
     *
     * @param [eventCallback] Claim view event callback
     *
     * <b>Since v4.0.0, User Consent feature is integrated into SDK.</b>
     *
     * If user have not provide consent yet, [RakutenReward.requestForConsent] API will be called to request for user's consent.
     * Once user provided consent will proceed claim action.
     *
     *
     */
    suspend fun claim(eventCallback: ((MissionClaimViewEvent) -> Unit)?): RewardApiResult<MissionAchievementData> {
        val eventItem = EventItem.createItem(EventNames.CLAIM_POINT).apply {
            addExtra(EventNames.EXTRA_FROM, EventNames.getNotificationFromValue(notificationtype))
        }
        SdkModuleApi.sendEvent(eventItem)
        val missionData = this.copy()
        return claim(missionData, eventCallback)
    }
}
