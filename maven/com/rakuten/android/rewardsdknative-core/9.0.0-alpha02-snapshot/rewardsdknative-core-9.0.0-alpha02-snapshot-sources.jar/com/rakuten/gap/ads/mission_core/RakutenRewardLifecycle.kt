package com.rakuten.gap.ads.mission_core

import android.app.Activity
import com.rakuten.gap.ads.mission_core.di.ContainerProvider
import com.rakuten.gap.ads.mission_core.di.provider.CoroutineProvider
import com.rakuten.gap.ads.mission_core.modules.singleton.RewardSDKActivityModule
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job

/**
 * Use this static APIs to start Reward SDK and sync user data
 *
 * <b>Sample usage<b/>
 * ```kotlin
 * class SampleActivity: Activity() {
 *
 *      override fun onCreate(savedInstanceState: Bundle?) {
 *          super.onCreate(savedInstanceState)
 *          RakutenRewardLifecycle.onCreate(this)
 *      }
 *
 *      override fun onStart() {
 *          super.onStart()
 *          RakutenRewardLifecycle.onStart(this)
 *      }
 *
 *      override fun onResume() {
 *          super.onResume()
 *          RakutenRewardLifecycle.onResume(this)
 *      }
 *
 *      override fun onDestroy() {
 *          super.onDestroy()
 *          RakutenRewardLifecycle.onDestroy()
 *      }
 * }
 * ```
 */
object RakutenRewardLifecycle {
    private var job: Job? = null

    @JvmStatic
    fun onCreate(activity: Activity) {
        RewardSDKActivityModule.onActivityCreate(activity)
    }

    internal fun onCreate(activity: Activity, coroutineScope: CoroutineScope) {
        ContainerProvider.getAppContainer().getProvider(CoroutineProvider::class.java)
            .setCoroutineScope(coroutineScope)
        RewardSDKActivityModule.onActivityCreate(activity)
    }

    @JvmStatic
    fun onStart(activity: Activity) {
        RewardSDKActivityModule.onActivityStart(activity)

        val newJob = Job().apply {
            job = this
        }
        ContainerProvider.getAppContainer().getProvider(CoroutineProvider::class.java)
            .setCoroutineScope(CoroutineScope(Dispatchers.Main + newJob))
    }

    internal fun onStart(activity: Activity, coroutineScope: CoroutineScope) {
        ContainerProvider.getAppContainer().getProvider(CoroutineProvider::class.java)
            .setCoroutineScope(coroutineScope)
        RewardSDKActivityModule.onActivityStart(activity)
    }

    @JvmStatic
    fun onResume(activity: Activity) {
        RewardSDKActivityModule.onActivityResume(activity)
    }

    @JvmStatic
    fun onDestroy() {
        RewardSDKActivityModule.onActivityDestroy()
        job?.cancel()
        job = null
    }

    /**
     * Prefer this over [onDestroy]: passing the Activity being destroyed lets the SDK keep UI
     * that should outlive this Activity - UI owned by another, still-alive Activity, or UI that
     * is expected to stay when this Activity is merely being recreated for a configuration
     * change such as a rotation.
     *
     * @param activity the Activity being destroyed
     */
    @JvmStatic
    fun onDestroy(activity: Activity) {
        RewardSDKActivityModule.onActivityDestroy(activity)
        job?.cancel()
        job = null
    }
}