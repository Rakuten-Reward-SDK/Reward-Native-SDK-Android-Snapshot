package com.rakuten.gap.ads.mission_core.status

/**
 * Login Option type
 */
enum class RakutenRewardTokentype {
    /**
     * Rakuten ID SDK, use API token for SDK.
     */
    RID,

    /**
     * Default login option. Reward SDk provide login API and handle token renewal.
     */
    RAKUTEN_AUTH
}